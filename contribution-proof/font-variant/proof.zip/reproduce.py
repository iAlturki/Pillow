"""Capture actual font-engine selection and rendering, without personal data."""

from pathlib import Path
import argparse
import hashlib
import json

from PIL import Image, ImageDraw, ImageFont, features


parser = argparse.ArgumentParser()
parser.add_argument("stage", choices=["before", "after"])
stage = parser.parse_args().stage
root = Path(__file__).resolve().parent
font_path = "Tests/fonts/DejaVuSans/DejaVuSans.ttf"
original = ImageFont.truetype(font_path, 54, layout_engine=ImageFont.Layout.RAQM)
actual = original.font_variant(layout_engine=ImageFont.Layout.BASIC)
reference = ImageFont.truetype(font_path, 54, layout_engine=ImageFont.Layout.BASIC)
text = "AVATAR office"

def render(font: ImageFont.FreeTypeFont) -> Image.Image:
    image = Image.new("RGB", (560, 100), "white")
    ImageDraw.Draw(image).text((16, 16), text, font=font, fill="black")
    return image

actual_image = render(actual)
reference_image = render(reference)
actual_image.save(root / (stage + "-actual.png"))
reference_image.save(root / "reference.png")
result = {
    "stage": stage,
    "pillow": Image.__version__,
    "freetype": features.version("freetype2"),
    "raqm": features.version("raqm"),
    "original_engine": original.layout_engine.name,
    "requested_engine": ImageFont.Layout.BASIC.name,
    "actual_engine": actual.layout_engine.name,
    "text": text,
    "actual_advance_px": actual.getlength(text),
    "reference_advance_px": reference.getlength(text),
    "matches_reference_pixels": actual_image.tobytes() == reference_image.tobytes(),
    "imagefont_source_sha256": hashlib.sha256(Path(ImageFont.__file__).read_bytes()).hexdigest(),
}
(root / (stage + "-render.json")).write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
